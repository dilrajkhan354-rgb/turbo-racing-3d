# Turbo Racing 3D — fresh Android game project

## Project structure
- `index.html`: game page (Vite entry point)
- `src/main.js`: Three.js gameplay and 3D scene
- `src/style.css`: touch controls and interface
- `package.json`: dependencies and commands
- `capacitor.config.json`: Android app settings

## Build from scratch (computer required)
1. Install Node.js LTS and Android Studio.
2. Extract this ZIP.
3. Open a terminal in the extracted `turbo_racing_3d_fresh` folder.
4. Install packages:
   `npm install`
5. Build the web game:
   `npm run build`
6. Add the Android platform:
   `npx cap add android`
7. Copy the built game into Android:
   `npx cap sync android`
8. Open Android Studio:
   `npx cap open android`
9. In Android Studio choose Build > Build Bundle(s) / APK(s) > Build APK(s).

## Test in a browser first
Run:
`npm run start`
Open the local URL Vite prints. The browser needs access to the internet only for initial package installation; the built game bundles Three.js locally.

## Notes
- This is a new starter project, not a precompiled APK.
- A computer with Android Studio is required to build the APK.
- For a release APK, configure app signing and test on the intended Android device.


## Phone-only APK route (cloud packaging)
1. Upload this project to a GitHub repository using GitHub in Chrome on your phone.
2. Import/connect the repository to a hosting service that supports Vite builds, such as Netlify. Set build command to `npm run build` and publish directory to `dist`.
3. After deployment, open the HTTPS website URL and test the game.
4. Open https://pwabuilder.com, enter the deployed website URL, and inspect the PWA report.
5. Choose Package for Stores / Android / Generate Package. Select the Android package option and download the generated package ZIP.
6. Extract the ZIP in Android Files and install the APK. Android may ask you to allow installation from that browser/files app; only proceed if you trust the source.
7. Keep your signing-key backup safe if you intend to update this app later.

Note: PWABuilder requires the game to be published over HTTPS with a valid web manifest. This is a cloud packaging path, not a guarantee that every account or current UI will provide the same buttons. An APK created this way loads the hosted game, so it normally needs internet access.
